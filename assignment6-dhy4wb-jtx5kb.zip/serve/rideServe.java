package serve;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.text.SimpleDateFormat;  
import java.util.Date; 

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class rideServe
 */
@WebServlet("/rideServe")
public class rideServe extends HttpServlet {
	static String url = "http://localhost:8080/Pool@UVA/serve.rideServe";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public rideServe() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
	    String passNum = request.getParameter("passNum");
	    String price = request.getParameter("price");
	    String toFro = request.getParameter("ToFro");
	    String city = request.getParameter("city");
	    String state = request.getParameter("state");
	    String comments = request.getParameter("comments");
	    String date = request.getParameter("date");
	    String time = request.getParameter("time");
	    
	    out.println("<body style=\"background-color:coral\">");
	    out.println("<b>Is this info correct?</b><br>");
	    out.println("<b>Number of People: </b>" + passNum + "<br>");
	    out.println("<b>Price per Person: </b>" + price + "<br>");
	    out.println("<b>To or From UVA: </b>" + toFro + "<br>");
	    out.println("<b>City: </b>" + city + "<br>");
	    out.println("<b>State: </b>" + state + "<br>");
	    out.println("<b>Notes: </b>" + comments + "<br>");
	    out.println("<b>Day Leaving: </b>" + date + "<br>");
	    out.println("<b>Time: </b>" + time + "<br>");

	    out.println("<form name = \"submit\" id = \"submit\" action = \"myrides.jsp\" method = \"POST\">");
	    out.println("	<input type=\"hidden\" name=\"num\" value="+passNum+">");
	    out.println("	<input type=\"hidden\" name=\"price\" value="+price+">");
	    out.println("	<input type=\"hidden\" name=\"toFrom\" value="+toFro+">");
	    out.println("	<input type=\"hidden\" name=\"city\" value="+city+">");
	    out.println("	<input type=\"hidden\" name=\"state\" value="+state+">");
	    out.println("	<input type=\"hidden\" name=\"comments\" value="+comments+">");
	    out.println("	<input type=\"hidden\" name=\"date\" value="+date+">");
	    out.println("	<input type=\"hidden\" name=\"time\" value="+time+">");
	    out.println("	<input type='submit'  value='Yes' />");
	    out.println("	<input type='button' onclick=\"location.href='javascript:history.back()';\" value='No' />");
	    out.println("</form>");
	}

}
