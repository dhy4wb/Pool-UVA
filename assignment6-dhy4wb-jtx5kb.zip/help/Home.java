package help;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Home
 */
@WebServlet("/Home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static String url = "http://localhost:8080/PoolUVA/Home"; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Home() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		 String action = request.getParameter("action");
	      if (action != null && action.equals("invalidate"))
	      {  // Called from the invalidate button, kill the session
	         // get session, then invalidate it
	    	 // HttpSession session = request.getSession();
	         session.invalidate();	  
	         response.sendRedirect("login.html");;                  
	      }
	      else {
	    	  out.println("<html>");
		         out.println("<head>");
		         out.println("<meta charset = \"UTF-8\">");
		         out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
//		         out.println("<meta name=\"author\" content = \")
		         out.println("<title>Home</title>");
		         out.println("<link rel=stylesheet href='styles/example-style.css' type='text/css'>");
		         out.println("<link rel=\"stylesheet\" href=\"style/main.css\">");
		         out.println("</head>");  
		         out.println("<body>");
		         out.println("  <div class = \"navbar\" >");
		         out.println("    <a href = \"myrides.jsp\">My Rides</a>");
		         out.println("    <a href = \"rider.html\">Find Rides</a>");
		         out.println("    <a href = \"driver.html\">Give Rides</a>");
		         out.println("    <a href = \"aboutus.html\">About Pool@UVA</a>");
		         out.println("    <a href = \" "+url+ "?action=invalidate\"  onclick=\"return confirm('Do you really want to Logout?');\">Logout</a>");
		         out.println("  </div>");
		         out.println("  <div class = \"rightnav container\" style = \"overflow-x:auto\">");
		         
		         if(request.getParameter("username")!=null) {
		        	 session.setAttribute("username", request.getParameter("username"));
		         }
		         if(request.getParameter("fname")!=null) {
		        	 session.setAttribute("username", request.getParameter("fname"));
		         }
		         out.println("    <h2 class = \"moved\"> Welcome"+" "+session.getAttribute("username")+"</h2>");
		         out.println("    <h2 class = \"moved\"> Current Rides </h2>");
		         out.println("    <table id = \"rideTable\" class = \"table\">");
		         out.println("    	<thead>");
		         out.println("    		<tr>");
		         out.println("    			<th>Date</th>");
		         out.println("    			<th>Time</th>");
		         out.println("    			<th>To</th>");
		         out.println("    			<th>From</th>");
		         out.println("    			<th>Driver</th>");
		         out.println("    			<th>Request</th>");
		         out.println("    		</tr>");
		         out.println("    		<tr>");
		         out.println("    			<td>3/10/2018</td>");
		         out.println("    			<td>5:00 PM</td>");
		         out.println("    			<td>Fairfax, VA</td>");
		         out.println("    			<td>UVA</td>");
		         out.println("    			<td>Jessica Xu</td>");
		         out.println("    			<td id = \"check\" ><input type=button value=' X '>");
		         out.println("    		</tr>");
		         out.println("  </div>");
		         out.println("</body>");
		         out.println("</html>");     
	      }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
