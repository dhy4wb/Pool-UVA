package help;

public class ridesBean {
	
	   private int num;
	   private int price;
	   private String toFrom;
	   private String city;
	   private String state;
	   private String notes;
	   private String date;
	   private String time;
	   public ridesBean()
	   {    	   
	   }
	   public String getTime() 
	   {
	      return time;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setTime(String nm)
	   {
	      this.time = nm; 
	   }
	   public String getDate() 
	   {
	      return date;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setDate(String nm)
	   {
	      this.date = nm; 
	   }
	   public String getNotes() 
	   {
	      return notes;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setNotes(String nm)
	   {
	      this.notes = nm; 
	   }
	   public String getState() 
	   {
	      return state;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setState(String nm)
	   {
	      this.state = nm; 
	   }
	   
	   public String getCity() 
	   {
	      return city;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setCity(String nm)
	   {
	      this.city = nm; 
	   }
	 
	   // property "name"
	   // naming convention: "get" followed by parameter's name that starts with an upper case
	   public int getNum() 
	   {
	      return num;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setNum(int nm)
	   {
	      this.num = nm; 
	   }
	   public int getPrice() 
	   {
	      return price;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setPrice(int nm)
	   {
	      this.price = nm; 
	   }
	   public String getToFrom() 
	   {
	      return toFrom;
	   }

	   // property "name"
	   // naming convention: "set" followed by parameter's name that starts with an upper case   
	   public void setToFrom(String nm)
	   {
	      this.toFrom = nm; 
	   }
	 
	   // property "email"


}
